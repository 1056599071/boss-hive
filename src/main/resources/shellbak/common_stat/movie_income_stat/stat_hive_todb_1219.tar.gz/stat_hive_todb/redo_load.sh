#./load_data_to_playdayuid.sh 20141011
./load_data_to_playdayuid.sh 20141012
./load_data_to_playdayuid.sh 20141013
./load_data_to_playdayuid.sh 20141014
./load_data_to_playdayuid.sh 20141015
./load_data_to_playdayuid.sh 20141016
./load_data_to_playdayuid.sh 20141017
./load_data_to_playdayuid.sh 20141018
./load_data_to_playdayuid.sh 20141019
./load_data_to_playdayuid.sh 20141020
./load_data_to_playdayuid.sh 20141021
./load_data_to_playdayuid.sh 20141022
./load_data_to_playdayuid.sh 20141023
./load_data_to_playdayuid.sh 20141024
./load_data_to_playdayuid.sh 20141025
./load_data_to_playdayuid.sh 20141026
./load_data_to_playdayuid.sh 20141027
~
~

~
